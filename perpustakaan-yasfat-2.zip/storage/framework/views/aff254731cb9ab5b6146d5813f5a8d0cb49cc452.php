
<?php $__env->startSection('content'); ?>


    <div class="row">

        <?php if(Auth::check()): ?>
            <?php if(Auth::user()->role == 'menunggu aktivasi'): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger" role="alert">
                        <h4 class="alert-heading">Peringatan!</h4>
                        <p>Akun anda sedang menunggu aktivasi. Silahkan hubungi admin untuk aktivasi akun anda.</p>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(session()->has('error')): ?>
        <div class="col-md-12">
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">Peringatan!</h4>
                <p>Buku Sedang Tidak Tersedia Atau Sudah Tidak Tersedia</p>
            </div>
        </div>
        <?php endif; ?>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6 col-12 margin-tb mb-5">
                <div class="card" style="height: 100%">
                    <div class="card-header text-center">
                        <h3 class="text-center card-title"><?php echo e($item->title); ?></h3>
                        <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <small
                                class="text-muted text-center"><?php echo e($category->title); ?><?php echo e($index < $item->categories->count() - 1 ? ', ' : ''); ?></small>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="card-body">
                        <div class="text-center">
                            <img src=" 
                        
                        <?php if($item->cover): ?> <?php echo e(asset('storage/cover/' . $item->cover)); ?>

                        <?php else: ?>
                            <?php echo e(asset('default.png')); ?> <?php endif; ?>
                        
                        
                        "
                                alt="" class="img-fluid w-50 ">
                        </div>
                        <div class="card-text pt-4">
                            <p><?php echo e($item->description); ?></p>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between justify-items-center">
                        <a href="/book/<?php echo e($item->id); ?>" class="btn btn-primary">Detail</a>
                        <div class="text-center">
                            <p>Stock : <?php echo e($item->jumlah); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1>Buku Tidak Ditemukan</h1>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat\resources\views/public/index.blade.php ENDPATH**/ ?>