
<?php $__env->startSection('content'); ?>
    <div>
        <div class="card">
            <div class="card-header"><?php echo e($user->name); ?></div>
            <div class="card-body">
                <div class="form-group">
                    <label for="name" class="form-label">Nama Lengkap:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="name" class="form-label">NISN:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($user->nisn); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="name" class="form-label">Kelas:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($user->class); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="name" class="form-label">Email:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($user->email); ?>" readonly>
                </div>

                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary">Edit Users</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat\resources\views/users/show.blade.php ENDPATH**/ ?>