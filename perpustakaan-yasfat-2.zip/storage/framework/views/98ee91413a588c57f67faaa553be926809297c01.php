
<?php $__env->startSection('title', 'Perpustakaan | Buku'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container contents">

        
        <?php if(session()->has('error')): ?>
            <?php if(Auth::user()->role == 'menunggu aktivasi'): ?>
                <div class="row">
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session('error')); ?></strong>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <div>
            <form action="/book" method="GET">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Cari Buku" aria-label="Cari Buku"
                        aria-describedby="button-addon2" name="search">
                    <select class="form-select" name="category">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Cari</button>
                </div>
            </form>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-sm-6 col-md-6 col-lg-4 mb-3">
                    <div class="card h-100">
                        <img draggable="false" class="img-fluid d-flex mx-auto my-4"
                            <?php if($item->cover != ''): ?> src="<?php echo e(asset('storage/cover/' . $item->cover)); ?>"
                    <?php else: ?>
                    src="<?php echo e(asset('default.png')); ?>" <?php endif; ?>
                            alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->title); ?></h5>
                            <p class="card-text">
                                Kode Buku: <?php echo e($item->book_code); ?>

                            </p>
                            <div class="d-flex justify-content-between">
                                <a href="/book/<?php echo e($item->id); ?>" class="btn btn-outline-primary">Detail</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-sm-6 col-md-6 col-lg-4 mb-3">
                    <div class="card h-100">
                        <img draggable="false" class="img-fluid d-flex mx-auto my-4" src="<?php echo e(asset('default.png')); ?>">

                        <div class="card-body">
                            <h5 class="card-title text-danger">Buku Tidak Di Temukan</h5>
                            <p class="card-text">
                                Kode Buku: -----
                            </p>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.second', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/public/list-book.blade.php ENDPATH**/ ?>