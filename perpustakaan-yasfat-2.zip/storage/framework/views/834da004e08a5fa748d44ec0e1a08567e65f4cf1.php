
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 col">
            <div class="card">
                <div class="card-header">
                    <h6 class="m-0 font-weight-bold text-primary">Book Detail</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col col-lg-4 col-12 mb-4">
                            <?php if($book->cover): ?>
                                <img src="<?php echo e(asset('storage/cover/' . $book->cover)); ?>" alt="image" class="img-fluid">
                            <?php else: ?>
                                <img src="<?php echo e(asset('default.png')); ?>" alt="image">
                            <?php endif; ?>
                        </div>
                        <div class="col col-lg-8 col-12">
                            <h3><?php echo e($book->title); ?></h3>
                            <?php $__currentLoopData = $book->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <small class="text-bold ">Category: <?php echo e($category->title); ?></small>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p class="text-muted">Author: <?php echo e($book->author->name); ?></p>
                            <p><?php echo e($book->description); ?></p>

                            <?php if(Auth::check()): ?>
                                <?php if(Auth::user()->role != 'menunggu aktivasi'): ?>
                                    <a href="/pinjam/buku/<?php echo e($book->id); ?>" class="btn btn-primary">Ajukan Pinjam</a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat\resources\views/public/book-detail.blade.php ENDPATH**/ ?>