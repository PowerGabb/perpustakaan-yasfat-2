
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 col">
            <div class="card">
                <div class="card-header">
                    <h3>Peraturan Peminjaman Buku 2024</h3>
                </div>
                <div class="card-body">
                    <h3 class="mb-4">Dengan Meminjam Buku <span class="text-primary"><?php echo e($data->title); ?></span> Maka Kamu Setuju:</h3>
                    <ol class=" mb-4"> 
                        
                        <li>Menjaga Kondisi Buku</li>
                        <li>Mengembalikan Buku Kurang Dari 7 Hari Setelah Di Pinjam</li>
                        <li>Mengembalikan Buku Kepada Penjaga Perpus</li>
                        <li>Menjaga Kondisi Perpustakaan</li>
                        <li>Mengganti Buku Apabila Hilang</li>


                    </ol>

                    <p class="text-danger">Setelah Kamu Menyetujui, Maka Tunggu Hingga Status Peminjaman Berubah</p>
                    <a href="/pinjam/buku/<?php echo e($data->id); ?>/sekarang" class="btn btn-primary">Pinjam Sekarang</a>
                    <a href="/" class="btn btn-danger">Batalkan</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat\resources\views/account/alert.blade.php ENDPATH**/ ?>