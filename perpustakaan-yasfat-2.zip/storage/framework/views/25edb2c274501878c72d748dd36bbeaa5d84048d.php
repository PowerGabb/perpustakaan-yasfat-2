
<?php $__env->startSection('content'); ?>
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0">Kembalikan Buku</h5>
                <small class="text-muted float-end"></small>
            </div>
            <div class="card-body">
                <form action="/rents-back" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="user">User dan buku yang dipinjam</label>
                        <div class="col-sm-10">
                            <select class="users form-control" name="id">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->user->name); ?> - <?php echo e($item->book->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan-yasfat-2\resources\views/rents/returning.blade.php ENDPATH**/ ?>